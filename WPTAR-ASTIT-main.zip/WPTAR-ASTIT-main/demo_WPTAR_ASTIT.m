%% =================================================================
% This script performs Weighted Schattern p and Tensor Average Rank for Infrared Small Target Detection 
% 
% More detail can be found in [1]
% [1] Yang Sun.
%     Adaptive Spatial-Temporal Tensor and Weighted Tensor Average Rank Approximation for Infrared Small Target Detection
%
% Created by Yang Sun 
% 12/02/2024
clc;
clear;
close all;
%% LibADMM-Toolbox Import
addpath(genpath('LibADMM-master'));
addpath(genpath('norm'));
%%  Hyper-parameter Setup

C = 50;
p = 0.8;
thre = 0.6;
H = 12;

%% Define H values and corresponding folder paths
baseDir = 'data\';
saveBaseDir = 'result\';

% sequences = {'Sequence1', 'Sequence2', 'Sequence3', 'Sequence4', 'Sequence5', 'Sequence6'};
sequences = {'Sequence4'};

% Initialize a variable to store processing times
processing_times = zeros(length(sequences), 1);

for seq_idx = 1:length(sequences)
    seq_name = sequences{seq_idx};
    folder_path = fullfile(baseDir, seq_name);
    SavePath = fullfile(saveBaseDir, seq_name);

    %% Ensure save path exists
    if ~exist(SavePath, 'dir')
        mkdir(SavePath);
    end

    %% Data loading %%
    files = dir(fullfile(folder_path, '*.bmp')); 
    num_images = length(files); % 统计图片数量

    %% Adaptive Sptial-Temporal Infrared Tensor Constrcution  
    k = num_images; % total image number
    D = zeros(size(imread(fullfile(folder_path, files(1).name)), 1), size(imread(fullfile(folder_path, files(1).name)), 2), k);
    for i = 1:k
        % fprintf('%d/%d: %s\n', num_images, i);
       picname = [folder_path, '\',num2str(i), '.bmp'];
        I = imread(picname);
        [~, ~, ch] = size(I);
        if ch == 3
            I = rgb2gray(I);
        end
        D(:,:,i) = I;
    end
    tenD = double(D);
    [n1, n2, n3] = size(tenD);
    n_1 = max(n1, n2); % n(1)
    n_2 = min(n1, n2); % n(2)
    [sub_tensor_indices, tempD, sub_tensor_number] = split_tensor_by_similarity(tenD, thre, 10); % 根据图像相似度自适应划分图像张量块
    tic
    patch_frames = zeros(sub_tensor_number,1);

    %% Model Processing %%
    tenB = cell(sub_tensor_number, 1); % 重置 tenB
    tenT = cell(sub_tensor_number, 1); % 重置 tenT
    for i = 1:sub_tensor_number
        temp = tempD{i};
        [~, ~, patch_frames(i)] = size(temp);
        T = C * sqrt(n1 * n2) ;
        lambda = H  / sqrt((n_1 * patch_frames(i)));
        par = [lambda; p; T];    
        [tenB{i}, tenT{i}, ~, stopCriterion] = WPTAR(temp, @IterativeWSNM, par(1), par(2), par(3), [1/3, 1/3, 1/3]);
    end

    %% Tensor Reconstruction %%
    reconstructed_B = concatenate_cells(tenB);
    reconstructed_T = concatenate_cells(tenT);

    %% Display Results %%    
    for i = 1:k
        tarImg = reconstructed_T(:,:,i);
        backImg = reconstructed_B(:,:,i);
        %% 阈值分割
        tarImg = mat2gray(tarImg) * 255;
        a = uint8(tarImg);  
        imwrite(a, fullfile(SavePath, [num2str(i), '.bmp']));
    end
end


