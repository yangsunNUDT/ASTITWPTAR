function d2=tnorm(D)
barD=fft(D,[],3);
[m,n,h]=size(barD);
DD=zeros(m*h,n*h);
for i=1:h
   DD(m*(i-1)+1:m*i,n*(i-1)+1:n*i)=barD(:,:,i);
end
d2=norm(DD);