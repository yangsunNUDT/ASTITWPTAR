%function [A E Z svp] = LRM_APGM0(D,  nsig, lambda, Elogic,option)
function [A E] = T4DRPCA_APGM(D, lambda,option)
% --------------------solve the following problem------------------------------------------


D = double(D);
[m,n,h] = size(D);
if nargin < 2
    lambda = 1 / sqrt(max(m,n)*h);
end
if nargin < 3
    option = [];
end

if ~isfield(option,'tau')  
    option.tau = 1/2.7;
end

if ~isfield(option,'tol')  
    option.tol = [1e-4 1e-3];
end

if ~isfield(option,'maxIter')  
    option.maxIter = 300 ;%300;
end

 

if ~isfield(option,'rho')  
    option.rho = 1.25;
end

if ~isfield(option,'visible')  
    option.visible = 0;
end
lambda=lambda/ sqrt(max(m,n)*h);
tau = option.tau;
tol = option.tol;
tol1 = tol(1);
tol2 = tol(2);
maxIter = option.maxIter;

visible = option.visible;
DISPLAY_EVERY = 10 ;

d_norm = norm(Unfold(D,size(D),1), 'fro');



% ��ʼ��
mu = 0.99*tnorm(D);
delta=0.9*10.^(-5);
muMin=delta*mu;
rho = 0.9;

E = zeros(m,n,h);
E_new = zeros(m,n,h);
A_new =zeros(m,n,h);
A =zeros(m,n,h);

t=1;
t_new=1;


% LambdaA = zeros(m,n,h);
% LambdaE = zeros(m,n,h);

iter = 0;
converged = false;

%tau=10;
 while ~converged       
     iter = iter + 1;

 % update LambdaA LambdaE
     LambdaA=A_new+(t-1)/t_new*(A_new-A);
     LambdaE=E_new+(t-1)/t_new*(E_new-E);
     
    % update A
    temp =  LambdaA-1/2*(LambdaA+LambdaE-D);
    %[U S V] = svd(temp, 'econ');
    %diagS = diag(S);
    %svp = length(find(diagS > mu/2)); %mu*tau
     %A_new = U *diag(diagS(1:svp)-mu/2)* V';
      [A_new,~] = prox_tnn(temp,mu/2);
    
    % update E
     temp =  LambdaE-1/2*(LambdaA+LambdaE-D);
    E_new = sign(temp).*max(abs(temp)-lambda*mu/2,0);

    t_new=(1+sqrt(4*t^2+1))/2;
   
   
  
    
    % update mu
    mu = max(muMin, mu*rho);
    
    % Stop
    A_Difnorm = norm(Unfold(A-A_new,size(A-A_new),1),'fro');
    E_Difnorm = norm(Unfold(E-E_new,size(E-E_new),1),'fro');
 
    x_norm = A_Difnorm+E_Difnorm;
 
    stoppingCriterion = x_norm/d_norm;
   
    
 
       
    if visible == 1 
        if mod( iter, DISPLAY_EVERY) == 0
            disp(['#Iteration ' num2str(iter)...% '  rank(A) ' num2str(svp)
                ' ||E||_0 ' num2str(length(find(abs(E)>0)))...
                '  Stopping Criterion ' ...
                 num2str(stoppingCriterion)]);
         end    
    end
    
    if    stoppingCriterion<= tol 
         if visible == 1 
             disp('RASL inner loop is converged at:');
             disp(['#Iteration ' num2str(iter) ...% '  rank(A) ' num2str(svp)
                 ' ||E||_0 ' num2str(length(find(abs(E)>0)))...
                 '  Stopping Criterion ' ...
                 num2str(stoppingCriterion)]);
        end
        converged = true ;
    end
    
     if ~converged && iter >= maxIter %
         if visible == 1 
             disp('Maximum iterations reached') ;
         end
         converged = true ;       
   end
 
   
end

    