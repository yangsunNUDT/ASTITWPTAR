function concatenated_tensor = concatenate_cells(cell_array)
    % concatenate_cells - 将多个cell里的三维张量拼接为一个张量
    % 输入:
    %   cell_array - 包含多个三维张量的cell数组
    % 输出:
    %   concatenated_tensor - 拼接后的三维张量

    % 获取第一个张量的尺寸
    first_tensor = cell_array{1};
    [height, width, num_images] = size(first_tensor);

    % 初始化拼接后的张量
    total_num_images = sum(cellfun(@(x) size(x, 3), cell_array));
    concatenated_tensor = zeros(height, width, total_num_images);

    % 拼接张量
    start_idx = 1;
    for i = 1:length(cell_array)
        current_tensor = cell_array{i};
        current_num_images = size(current_tensor, 3);
        concatenated_tensor(:, :, start_idx:(start_idx + current_num_images - 1)) = current_tensor;
        start_idx = start_idx + current_num_images;
    end
end

% 示例调用
% cell_array = {tensor1, tensor2, tensor3}; % 假设你有多个三维张量
% concatenated_tensor = concatenate_cells(cell_array);
% disp(concatenated_tensor);