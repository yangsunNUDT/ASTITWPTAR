function [sub_tensor_indices, tempD, K] = split_tensor_by_similarity(D, threshold, max_images_per_block)
    % split_tensor_by_similarity - 根据图像相似度分块图像张量
    % 输入:
    %   D - 图像张量，维度为 (height, width, num_images)
    %   threshold - 相似度阈值，默认为0.6
    %   max_images_per_block - 每个子张量块的最大图像数量，默认为10
    % 输出:
    %   sub_tensor_indices - 每个子张量块的第三个维度索引
    %   tempD - 每个子张量块的图像张量
    %   K - 子张量块的数量

    if nargin < 2
        threshold = 0.6;
    end

    if nargin < 3
        max_images_per_block = 10;
    end

    num_images = size(D, 3);
    sub_tensor_indices = {};
    tempD = {};
    start_idx = 1;
    k = 1;

    for i = 2:num_images-1
        % 检查当前子张量块的长度是否超过 max_images_per_block
        if i - start_idx >= max_images_per_block
            % 强制分割
            sub_tensor_indices{end+1} = start_idx:(start_idx + max_images_per_block - 1);
            tempD{k} = D(:, :, start_idx:(start_idx + max_images_per_block - 1));
            k = k + 1;
            start_idx = start_idx + max_images_per_block;
        end

        % 如果当前子张量块的长度未超过 max_images_per_block，继续检查相似度
        if i - start_idx < max_images_per_block
            img1 = D(:, :, start_idx);
            img2 = D(:, :, i);

            % 计算SSIM
            ssim_val = ssim(img1, img2);

            % 判断相似度是否满足条件
            if ssim_val < threshold
                % 检查子张量块的长度是否满足要求
                if i - start_idx >= 1
                    sub_tensor_indices{end+1} = start_idx:i;
                    tempD{k} = D(:, :, start_idx:i);
                end
                start_idx = i + 1;
                if i == num_images
                    break
                else 
                    k = k + 1;
                end
            end
        end
    end

    % 处理最后一个子张量块
    if num_images - start_idx >= 1
        if num_images - start_idx > max_images_per_block
            % 强制分割
            sub_tensor_indices{end+1} = start_idx:(start_idx + max_images_per_block - 1);
            tempD{k} = D(:, :, start_idx:(start_idx + max_images_per_block - 1));
            k = k + 1;
            sub_tensor_indices{end+1} = (start_idx + max_images_per_block):num_images;
            tempD{k} = D(:, :, (start_idx + max_images_per_block):num_images);
        else
            sub_tensor_indices{end+1} = start_idx:num_images;
            tempD{k} = D(:, :, start_idx:num_images);
        end
    end

    % 确保最后一个子张量块包含最后一帧图像
    if sub_tensor_indices{end}(end) ~= num_images
        sub_tensor_indices{end} = [sub_tensor_indices{end}, num_images];
        tempD{end} = D(:, :, sub_tensor_indices{end});
    end

    K = length(sub_tensor_indices);
end