%------------------------------------------------------------------
% Solve the following optimization problem using ADMM method
% argmin_{A,E} lambda_1 \sum_k alpha_k||A^{T_k}||^{p}_w,p��w,a + beta* ||S||^{p}_p
% +||D-A-S||_F^2,
% where D,A,S are tensors. 

 
function [A, E, r,changeofOBJ] = WPTAR(D, fun,lambda, p, T, alpha,option )

if nargin<6
    alpha = [1/3 1/3 1/3];
end

if nargin < 7
    option = [];
end

if ~isfield(option,'tol')
    option.tol = 1e-6;%���� tolerance��Ĭ��Ϊ 1e-8
end

if ~isfield(option,'maxIter')
    option.maxIter = 500;%������������Ĭ��Ϊ 500
end

if ~isfield(option,'mu')
    option.mu1 = 1e-2;%����������Ĭ��Ϊ 1e-2
    option.mu2 = 1e-2;
    option.mu3 = 1e-2;
end

if ~isfield(option,'visible')
    option.visible = 0;
end


tol = option.tol;
maxIter = option.maxIter;
mu1= option.mu1;
mu2= option.mu2;
mu3 = option.mu3;
visible = option.visible;

DISPLAY_EVERY = 10 ;%ÿ���ٴε�����ʾһ����Ϣ
mu_bar = 1e10;%����
rho = 1.1; %������������        
d_norm = norm3_fro(D);
[m1 m2 m3] = size(D);

% ��ʼ��
E = zeros(size(D));
A = D;
Q_1 = zeros(m2,m3,m1);%��ʼ���������ճ���
Q_2 = zeros(m3,m1,m2);
Q_3 = zeros(m1,m2,m3);
normweight=T;%W_pȨ�س���
weight_option=1;%�����Ƿ���W_p�����¼�Ȩ��1��ʾ��Ȩ������Ϊ0����������ʵ��
preTnnT =0;
iter = 0;
converged = false;
change=zeros(1,maxIter);
while ~converged  && iter < maxIter
    iter = iter + 1;
    % update M_1,M_2,M_3
    temp = permute(A,[2 3 1]) +(1/mu1)*Q_1;
    M_1  = prox_tnn1(temp,normweight*alpha(1)/mu1,p);

    temp =permute(A,[3 1 2])+(1/mu2)*Q_2;
    M_2  = prox_tnn1(temp,normweight*alpha(2)/mu2,p);

    temp =  A+(1/mu3)*Q_3;
    M_3  = prox_tnn1(temp,normweight*alpha(3)/mu3,p);


    % update A
    TenTemp1 =  mu1*M_1-Q_1;
    TenTemp2 =  mu2*M_2-Q_2 ;
    TenTemp3 =  mu3*M_3-Q_3 ;
    A = (D-E+permute(TenTemp1,[3 1 2])+permute(TenTemp2,[2 3 1])+TenTemp3)/(mu3+mu1+mu2+1);

    % update E
    temp = D - A;
    E= IterativeWSNM_T(temp, lambda, p, 0, m1, m2);
 

    % update Q_i
    Q_1 = Q_1 + mu1*( permute(A,[2 3 1])-M_1);
    Q_2 = Q_2 + mu2*(permute(A,[3 1 2])-M_2);
    Q_3 = Q_3 + mu3*(A-M_3);


    mu1 = min(mu1*rho, mu_bar);
    mu2 = min(mu2*rho, mu_bar);
    mu3 = min(mu3*rho, mu_bar);

    %% stop Criterion-version1 
    dif1 = norm3_fro(permute(A,[2 3 1])-M_1);
    dif2 = norm3_fro(permute(A,[3 1 2])-M_2);
    dif3 = norm3_fro(A-M_3);
    stopCriterion = (dif1+dif2+dif3) / d_norm;
    changeofOBJ(iter)=(stopCriterion);
     if stopCriterion < tol
        converged = true;
    end

    if visible == 1
        if mod( iter, DISPLAY_EVERY) == 0
            disp(['#Iter ' num2str(iter) 'rank(M1) ' num2str(tubalrank(M_1)) ...
                '  rank(M2) ' num2str(tubalrank(M_2))  '  rank(M3) ' num2str(tubalrank(M_3))...
                ' |D-A|_F ' num2str(norm3_fro(D-A))...
                ' stopCriterion ' num2str(stopCriterion)]);
        end
    end
    if ~converged && iter >= maxIter
        if visible == 1
            disp('Maximum iterations reached') ;
        end
        converged = 1 ;
    end
end
r = tubalrank(M_3);

