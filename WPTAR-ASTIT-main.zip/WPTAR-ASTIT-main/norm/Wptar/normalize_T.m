function x = normalize_T(x)
    % 对三维数组x的每个2D切片进行阈值处理和归一化
    for i = 1:size(x,3)
        temp_slice = x(:,:,i);
        [n1, n2] = size(temp_slice);
        temp1 = reshape(temp_slice, n1*n2, 1);
        tar_mean = mean(temp1);
        tar_sigma = std(temp1);
        Thre = max(max(temp1) * 0.65, 0.5 * tar_sigma + tar_mean);
        index = temp_slice > Thre;
        x(:,:,i) = temp_slice .* index;
        x(:,:,i) = mat2gray(x(:,:,i)) * 255;
    end
end