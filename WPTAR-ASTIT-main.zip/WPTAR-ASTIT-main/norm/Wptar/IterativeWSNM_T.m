function [ SigmaX, svp ] = IterativeWSNM_T( SigmaY, C, p, weight_option,m1,m2 )
if nargin<4
    weight_option = 1;
end

p1    =   p;    
Temp  =   SigmaY;
s     =   SigmaY;
s1    =   zeros(size(s));

for i=1:3
    if weight_option == 1
       W_Vec    =   C./( (Temp) + eps );  
    end
    if weight_option == 0
       W_Vec    =   C*ones(size(Temp));
    end  
   [s1, svp]=   solve_Lp_w_T(s, W_Vec, p1,m1,m2);
   Temp     =   s1;
end
SigmaX = s1;

end
