function fro=norm3_fro(A)
fro=sqrt(sum(sum(sum(A.*A))));